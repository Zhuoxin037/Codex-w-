tag @s add dl.welcome
gamemode adventure @s
tp @s 0.5 81 5.4 180 3
tellraw @s {text:"按右前方的按钮抽取。",color:"gold"}
