data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.31580f,0f,0.94883f]}}
tp @e[tag=dl.left,distance=0..,limit=1] 1.0861 82.4638 0.7052
data merge entity @e[tag=dl.left,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.66720f,0.66720f,0.66720f],left_rotation:[0f,0.13371f,0f,0.99102f]}}
tp @e[tag=dl.right,distance=0..,limit=1] -0.0861 82.4638 0.7052
data merge entity @e[tag=dl.right,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.66720f,0.66720f,0.66720f],left_rotation:[0f,-0.13371f,0f,0.99102f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.5 83.1691 0.822
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.43880f,1.43880f,1.43880f],left_rotation:[0f,0.10412f,0f,0.99456f]}}
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.3865 83.03 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.319 83.3693 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.1269 83.6569 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.8393 83.849 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.5 83.9165 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.1607 83.849 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.1269 83.6569 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.319 83.3693 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.3865 83.03 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.319 82.6907 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.1269 82.4031 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.1607 82.211 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.5 82.1435 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.8393 82.211 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.1269 82.4031 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.319 82.6907 0.82 .018 .018 .014 0 1 normal
