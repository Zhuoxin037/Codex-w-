execute in minecraft:overworld if score #built dl.state matches 1 run function drawlab:tick_stage
