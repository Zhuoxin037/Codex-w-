data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.72256f,0f,0.69131f]}}
tp @e[tag=dl.card_0,distance=0..,limit=1] 0.5907 82.5687 1.6966
data merge entity @e[tag=dl.card_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.5907 82.5687 1.7786
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_1,distance=0..,limit=1] -0.5029 82.1082 0.5761
data merge entity @e[tag=dl.card_1,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.74941f,0.74941f,0.74941f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_1,distance=0..,limit=1] -0.5029 82.1082 0.6581
data merge entity @e[tag=dl.icon_1,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.46464f,0.46464f,0.46464f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
particle minecraft:electric_spark -0.5029 82.1082 0.5761 .10 .14 .12 .018 4 normal
tp @e[tag=dl.card_2,distance=0..,limit=1] 0.4103 82.5311 -0.6824
data merge entity @e[tag=dl.card_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.98163f,0.98163f,0.98163f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_2,distance=0..,limit=1] 0.4103 82.5311 -0.6004
data merge entity @e[tag=dl.icon_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.60861f,0.60861f,0.60861f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_3,distance=0..,limit=1] 1.6966 82.5527 0.4093
data merge entity @e[tag=dl.card_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_3,distance=0..,limit=1] 1.6966 82.5527 0.4913
data merge entity @e[tag=dl.icon_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
