data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.75356f,0f,0.65738f]}}
tp @e[tag=dl.card_0,distance=0..,limit=1] 0.5 82.5989 1.6417
data merge entity @e[tag=dl.card_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.01822f,1.01822f,1.01822f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.5 82.5989 1.7237
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.63130f,0.63130f,0.63130f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
kill @e[tag=dl.card_1,distance=0..,limit=1]
kill @e[tag=dl.icon_1,distance=0..,limit=1]
tp @e[tag=dl.card_2,distance=0..,limit=1] 0.5 81.8448 -0.4056
data merge entity @e[tag=dl.card_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62014f,0.62014f,0.62014f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_2,distance=0..,limit=1] 0.5 81.8448 -0.3236
data merge entity @e[tag=dl.icon_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.38449f,0.38449f,0.38449f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_3,distance=0..,limit=1] 1.6155 82.3459 0.5
data merge entity @e[tag=dl.card_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.89094f,0.89094f,0.89094f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_3,distance=0..,limit=1] 1.6155 82.3459 0.582
data merge entity @e[tag=dl.icon_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.55238f,0.55238f,0.55238f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
particle minecraft:electric_spark 1.6155 82.3459 0.5 .10 .14 .12 .018 4 normal
playsound minecraft:block.copper.place block @a[distance=..28] 0.5 81 0.5 .62 .83
