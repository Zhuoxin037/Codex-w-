data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.48818f,0f,0.87274f]}}
tp @e[tag=dl.card_0,distance=0..,limit=1] 1.3673 82.5711 -0.3293
data merge entity @e[tag=dl.card_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 1.3673 82.5711 -0.2473
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_1,distance=0..,limit=1] 1.3293 82.5603 1.3673
data merge entity @e[tag=dl.card_1,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_1,distance=0..,limit=1] 1.3293 82.5603 1.4493
data merge entity @e[tag=dl.icon_1,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_2,distance=0..,limit=1] -0.3673 82.5492 1.3293
data merge entity @e[tag=dl.card_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_2,distance=0..,limit=1] -0.3673 82.5492 1.4113
data merge entity @e[tag=dl.icon_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_3,distance=0..,limit=1] -0.3293 82.548 -0.3673
data merge entity @e[tag=dl.card_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_3,distance=0..,limit=1] -0.3293 82.548 -0.2853
data merge entity @e[tag=dl.icon_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
particle minecraft:dust{color:[.32,.73,.62],scale:.69} 1.4035 82.05 -0.3638 .022 .018 .022 0 2 normal
particle minecraft:dust{color:[.32,.73,.62],scale:.69} 1.151 82.05 -0.5671 .022 .018 .022 0 2 normal
particle minecraft:dust{color:[.32,.73,.62],scale:.69} 0.8548 82.05 -0.6986 .022 .018 .022 0 2 normal
