data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.25225f,0f,0.96766f]}}
tp @e[tag=dl.card_0,distance=0..,limit=1] 1.3077 82.5487 1.3875
data merge entity @e[tag=dl.card_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 1.3077 82.5487 1.4695
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_1,distance=0..,limit=1] -0.3875 82.5485 1.3077
data merge entity @e[tag=dl.card_1,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_1,distance=0..,limit=1] -0.3875 82.5485 1.3897
data merge entity @e[tag=dl.icon_1,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_2,distance=0..,limit=1] -0.3077 82.5589 -0.3875
data merge entity @e[tag=dl.card_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_2,distance=0..,limit=1] -0.3077 82.5589 -0.3055
data merge entity @e[tag=dl.icon_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_3,distance=0..,limit=1] 1.3875 82.5703 -0.3077
data merge entity @e[tag=dl.card_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_3,distance=0..,limit=1] 1.3875 82.5703 -0.2257
data merge entity @e[tag=dl.icon_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
playsound minecraft:block.note_block.bit block @a[distance=..28] 0.5 81 0.5 .29 1.49
particle minecraft:dust{color:[.32,.73,.62],scale:.69} 1.3414 82.05 1.4244 .022 .018 .022 0 2 normal
particle minecraft:dust{color:[.32,.73,.62],scale:.69} 1.5507 82.05 1.1771 .022 .018 .022 0 2 normal
particle minecraft:dust{color:[.32,.73,.62],scale:.69} 1.6895 82.05 0.8842 .022 .018 .022 0 2 normal
