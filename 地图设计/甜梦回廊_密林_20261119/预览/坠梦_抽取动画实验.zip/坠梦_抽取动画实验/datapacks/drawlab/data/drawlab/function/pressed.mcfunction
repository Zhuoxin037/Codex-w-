execute if score #pressed dl.state matches 1 run return 0
scoreboard players set #pressed dl.state 1
execute if score #time dl.state matches ..-1 run function drawlab:start
