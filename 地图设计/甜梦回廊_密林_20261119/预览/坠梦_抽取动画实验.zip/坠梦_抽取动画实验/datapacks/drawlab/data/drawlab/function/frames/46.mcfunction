data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.45466f,0f,0.89066f]}}
kill @e[tag=dl.card_0,distance=0..,limit=1]
summon minecraft:item_display 0.5 82.8962 1.0105 {Tags:["dl.play","dl.left"],billboard:"vertical",brightness:{block:15,sky:13},view_range:1.0f,teleport_duration:2,item_display:"none",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"drawlab:tablet_left"}},transformation:{translation:[0f,0f,0f],scale:[1.21547f,1.21547f,1.21547f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:item_display 0.5 82.8962 1.0105 {Tags:["dl.play","dl.right"],billboard:"vertical",brightness:{block:15,sky:13},view_range:1.0f,teleport_duration:2,item_display:"none",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"drawlab:tablet_right"}},transformation:{translation:[0f,0f,0f],scale:[1.21547f,1.21547f,1.21547f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
tp @e[tag=dl.left,distance=0..,limit=1] 0.5 82.8962 1.0105
data merge entity @e[tag=dl.left,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.21547f,1.21547f,1.21547f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.right,distance=0..,limit=1] 0.5 82.8962 1.0105
data merge entity @e[tag=dl.right,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.21547f,1.21547f,1.21547f],left_rotation:[0f,-0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.5 82.8962 1.0925
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.75359f,0.75359f,0.75359f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_3,distance=0..,limit=1] 1.339 81.6996 0.5
data merge entity @e[tag=dl.card_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.53421f,0.53421f,0.53421f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_3,distance=0..,limit=1] 1.339 81.6996 0.582
data merge entity @e[tag=dl.icon_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.33121f,0.33121f,0.33121f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
