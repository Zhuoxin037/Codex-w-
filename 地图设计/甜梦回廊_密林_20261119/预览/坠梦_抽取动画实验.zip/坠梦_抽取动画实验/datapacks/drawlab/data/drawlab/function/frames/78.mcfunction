data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.44762f,0f,0.89422f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.5 83.17 0.822
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.44300f,1.44300f,1.44300f],left_rotation:[0f,0.10481f,0f,0.99449f]}}
