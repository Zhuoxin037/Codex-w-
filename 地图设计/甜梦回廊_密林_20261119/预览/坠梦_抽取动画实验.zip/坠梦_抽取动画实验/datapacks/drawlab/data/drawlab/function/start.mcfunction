kill @e[tag=dl.play,distance=0..]
execute store result score #draw dl.state run random value 0..3
scoreboard players add #runs dl.state 1
scoreboard players set #time dl.state 0
execute if score #draw dl.state matches 0 run function drawlab:cast/0
execute if score #draw dl.state matches 1 run function drawlab:cast/1
execute if score #draw dl.state matches 2 run function drawlab:cast/2
execute if score #draw dl.state matches 3 run function drawlab:cast/3
playsound minecraft:block.amethyst_block.hit block @a[distance=..28] 0.5 81 0.5 .67 .72
