data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.64271f,0f,0.76611f]}}
tp @e[tag=dl.card_0,distance=0..,limit=1] 0.5 82.728 1.3621
data merge entity @e[tag=dl.card_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.10560f,1.10560f,1.10560f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.5 82.728 1.4441
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.68547f,0.68547f,0.68547f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
kill @e[tag=dl.card_2,distance=0..,limit=1]
kill @e[tag=dl.icon_2,distance=0..,limit=1]
tp @e[tag=dl.card_3,distance=0..,limit=1] 1.4574 81.9739 0.5
data merge entity @e[tag=dl.card_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.68693f,0.68693f,0.68693f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_3,distance=0..,limit=1] 1.4574 81.9739 0.582
data merge entity @e[tag=dl.icon_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.42590f,0.42590f,0.42590f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
particle minecraft:electric_spark 1.4574 81.9739 0.5 .10 .14 .12 .018 4 normal
