data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.30140f,0f,0.95350f]}}
tp @e[tag=dl.left,distance=0..,limit=1] 0.5844 82.935 0.7619
data merge entity @e[tag=dl.left,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.20105f,1.20105f,1.20105f],left_rotation:[0f,0.01931f,0f,0.99981f]}}
tp @e[tag=dl.right,distance=0..,limit=1] 0.4156 82.935 0.7619
data merge entity @e[tag=dl.right,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.20105f,1.20105f,1.20105f],left_rotation:[0f,-0.01931f,0f,0.99981f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.5 83.0365 0.8489
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.89134f,0.89134f,0.89134f],left_rotation:[0f,0.01502f,0f,0.99989f]}}
kill @e[tag=dl.card_3,distance=0..,limit=1]
kill @e[tag=dl.icon_3,distance=0..,limit=1]
playsound minecraft:block.amethyst_block.chime block @a[distance=..28] 0.5 83.01 0.83 .8 1.26
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.9358 83.03 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.9027 83.1968 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.8082 83.3382 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.6668 83.4327 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.5 83.4658 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.3332 83.4327 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.1918 83.3382 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.0973 83.1968 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.0642 83.03 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.0973 82.8632 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.1918 82.7218 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.3332 82.6273 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.5 82.5942 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.6668 82.6273 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.8082 82.7218 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.9027 82.8632 0.82 .018 .018 .014 0 1 normal
