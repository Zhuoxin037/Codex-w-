fill -14 77 -14 14 79 14 minecraft:rooted_dirt
fill -14 80 -14 14 80 14 minecraft:moss_block
fill 0 80 -7 0 80 -7 minecraft:mossy_stone_bricks
fill -3 80 -6 3 80 -6 minecraft:mossy_stone_bricks
fill -4 80 -5 4 80 -5 minecraft:mossy_stone_bricks
fill -5 80 -4 5 80 -4 minecraft:mossy_stone_bricks
fill -6 80 -3 6 80 -3 minecraft:mossy_stone_bricks
fill -6 80 -2 6 80 -2 minecraft:mossy_stone_bricks
fill -6 80 -1 6 80 -1 minecraft:mossy_stone_bricks
fill -6 80 0 6 80 0 minecraft:mossy_stone_bricks
fill -7 80 1 7 80 1 minecraft:mossy_stone_bricks
fill -6 80 2 6 80 2 minecraft:mossy_stone_bricks
fill -6 80 3 6 80 3 minecraft:mossy_stone_bricks
fill -6 80 4 6 80 4 minecraft:mossy_stone_bricks
fill -6 80 5 6 80 5 minecraft:mossy_stone_bricks
fill -5 80 6 5 80 6 minecraft:mossy_stone_bricks
fill -4 80 7 4 80 7 minecraft:mossy_stone_bricks
fill -3 80 8 3 80 8 minecraft:mossy_stone_bricks
fill 0 80 9 0 80 9 minecraft:mossy_stone_bricks
fill 0 80 -6 0 80 -6 minecraft:tuff_bricks
fill -3 80 -5 3 80 -5 minecraft:tuff_bricks
fill -4 80 -4 4 80 -4 minecraft:tuff_bricks
fill -4 80 -3 4 80 -3 minecraft:tuff_bricks
fill -5 80 -2 5 80 -2 minecraft:tuff_bricks
fill -5 80 -1 5 80 -1 minecraft:tuff_bricks
fill -5 80 0 5 80 0 minecraft:tuff_bricks
fill -6 80 1 6 80 1 minecraft:tuff_bricks
fill -5 80 2 5 80 2 minecraft:tuff_bricks
fill -5 80 3 5 80 3 minecraft:tuff_bricks
fill -5 80 4 5 80 4 minecraft:tuff_bricks
fill -4 80 5 4 80 5 minecraft:tuff_bricks
fill -4 80 6 4 80 6 minecraft:tuff_bricks
fill -3 80 7 3 80 7 minecraft:tuff_bricks
fill 0 80 8 0 80 8 minecraft:tuff_bricks
fill 0 80 -4 0 80 -4 minecraft:polished_tuff
fill -2 80 -3 2 80 -3 minecraft:polished_tuff
fill -3 80 -2 3 80 -2 minecraft:polished_tuff
fill -3 80 -1 3 80 -1 minecraft:polished_tuff
fill -4 80 0 4 80 0 minecraft:polished_tuff
fill -3 80 1 3 80 1 minecraft:polished_tuff
fill -3 80 2 3 80 2 minecraft:polished_tuff
fill -2 80 3 2 80 3 minecraft:polished_tuff
fill 0 80 4 0 80 4 minecraft:polished_tuff
fill 0 80 -3 0 80 -3 minecraft:chiseled_tuff
fill -2 80 -2 2 80 -2 minecraft:chiseled_tuff
fill -2 80 -1 2 80 -1 minecraft:chiseled_tuff
fill -3 80 0 3 80 0 minecraft:chiseled_tuff
fill -2 80 1 2 80 1 minecraft:chiseled_tuff
fill -2 80 2 2 80 2 minecraft:chiseled_tuff
fill 0 80 3 0 80 3 minecraft:chiseled_tuff
fill -2 80 4 2 80 9 minecraft:polished_tuff
fill -1 80 8 1 80 14 minecraft:coarse_dirt
fill -10 81 -9 -9 90 -8 minecraft:dark_oak_log
fill -11 88 -10 -9 88 -10 minecraft:dark_oak_log[axis=x]
fill -12 89 -10 -8 90 -8 minecraft:dark_oak_leaves[persistent=true]
fill -11 89 -11 -9 90 -7 minecraft:dark_oak_leaves[persistent=true]
fill -11 91 -10 -9 92 -8 minecraft:dark_oak_leaves[persistent=true]
fill -11 93 -10 -9 93 -8 minecraft:dark_oak_leaves[persistent=true]
fill -5 81 -12 -4 90 -11 minecraft:dark_oak_log
fill -6 88 -13 -4 88 -13 minecraft:dark_oak_log[axis=x]
fill -7 89 -13 -3 90 -11 minecraft:dark_oak_leaves[persistent=true]
fill -6 89 -14 -4 90 -10 minecraft:dark_oak_leaves[persistent=true]
fill -6 91 -13 -4 92 -11 minecraft:dark_oak_leaves[persistent=true]
fill -6 93 -13 -4 93 -11 minecraft:dark_oak_leaves[persistent=true]
fill 2 81 -13 3 89 -12 minecraft:dark_oak_log
fill 0 87 -14 4 87 -14 minecraft:dark_oak_log[axis=x]
fill -1 88 -15 5 89 -11 minecraft:dark_oak_leaves[persistent=true]
fill 0 88 -16 4 89 -10 minecraft:dark_oak_leaves[persistent=true]
fill 0 90 -15 4 91 -11 minecraft:dark_oak_leaves[persistent=true]
fill 1 92 -14 3 92 -12 minecraft:dark_oak_leaves[persistent=true]
fill 8 81 -11 9 91 -10 minecraft:dark_oak_log
fill 7 89 -12 9 89 -12 minecraft:dark_oak_log[axis=x]
fill 6 90 -12 10 91 -10 minecraft:dark_oak_leaves[persistent=true]
fill 7 90 -13 9 91 -9 minecraft:dark_oak_leaves[persistent=true]
fill 7 92 -12 9 93 -10 minecraft:dark_oak_leaves[persistent=true]
fill 7 94 -12 9 94 -10 minecraft:dark_oak_leaves[persistent=true]
fill 11 81 -7 12 89 -6 minecraft:dark_oak_log
fill 10 87 -8 12 87 -8 minecraft:dark_oak_log[axis=x]
fill 9 88 -8 13 89 -6 minecraft:dark_oak_leaves[persistent=true]
fill 10 88 -9 12 89 -5 minecraft:dark_oak_leaves[persistent=true]
fill 10 90 -8 12 91 -6 minecraft:dark_oak_leaves[persistent=true]
fill 10 92 -8 12 92 -6 minecraft:dark_oak_leaves[persistent=true]
fill -12 81 -2 -11 90 -1 minecraft:dark_oak_log
fill -13 88 -3 -11 88 -3 minecraft:dark_oak_log[axis=x]
fill -14 89 -3 -10 90 -1 minecraft:dark_oak_leaves[persistent=true]
fill -13 89 -4 -11 90 0 minecraft:dark_oak_leaves[persistent=true]
fill -13 91 -3 -11 92 -1 minecraft:dark_oak_leaves[persistent=true]
fill -13 93 -3 -11 93 -1 minecraft:dark_oak_leaves[persistent=true]
fill -11 81 5 -10 88 6 minecraft:dark_oak_log
fill -12 86 4 -10 86 4 minecraft:dark_oak_log[axis=x]
fill -13 87 4 -9 88 6 minecraft:dark_oak_leaves[persistent=true]
fill -12 87 3 -10 88 7 minecraft:dark_oak_leaves[persistent=true]
fill -12 89 4 -10 90 6 minecraft:dark_oak_leaves[persistent=true]
fill -12 91 4 -10 91 6 minecraft:dark_oak_leaves[persistent=true]
fill 12 81 1 13 89 2 minecraft:dark_oak_log
fill 11 87 0 13 87 0 minecraft:dark_oak_log[axis=x]
fill 10 88 0 14 89 2 minecraft:dark_oak_leaves[persistent=true]
fill 11 88 -1 13 89 3 minecraft:dark_oak_leaves[persistent=true]
fill 11 90 0 13 91 2 minecraft:dark_oak_leaves[persistent=true]
fill 11 92 0 13 92 2 minecraft:dark_oak_leaves[persistent=true]
fill 10 81 6 11 90 7 minecraft:dark_oak_log
fill 8 88 5 12 88 5 minecraft:dark_oak_log[axis=x]
fill 7 89 4 13 90 8 minecraft:dark_oak_leaves[persistent=true]
fill 8 89 3 12 90 9 minecraft:dark_oak_leaves[persistent=true]
fill 8 91 4 12 92 8 minecraft:dark_oak_leaves[persistent=true]
fill 9 93 5 11 93 7 minecraft:dark_oak_leaves[persistent=true]
fill -7 81 11 -6 88 12 minecraft:dark_oak_log
fill -8 86 10 -6 86 10 minecraft:dark_oak_log[axis=x]
fill -9 87 10 -5 88 12 minecraft:dark_oak_leaves[persistent=true]
fill -8 87 9 -6 88 13 minecraft:dark_oak_leaves[persistent=true]
fill -8 89 10 -6 90 12 minecraft:dark_oak_leaves[persistent=true]
fill -8 91 10 -6 91 12 minecraft:dark_oak_leaves[persistent=true]
fill 8 81 11 9 88 12 minecraft:dark_oak_log
fill 7 86 10 9 86 10 minecraft:dark_oak_log[axis=x]
fill 6 87 10 10 88 12 minecraft:dark_oak_leaves[persistent=true]
fill 7 87 9 9 88 13 minecraft:dark_oak_leaves[persistent=true]
fill 7 89 10 9 90 12 minecraft:dark_oak_leaves[persistent=true]
fill 7 91 10 9 91 12 minecraft:dark_oak_leaves[persistent=true]
setblock -9 80 -6 minecraft:podzol
setblock -9 81 -6 minecraft:fern
setblock -8 80 -6 minecraft:moss_block
setblock -9 80 -5 minecraft:rooted_dirt
setblock -9 81 -5 minecraft:moss_carpet
setblock -10 80 -6 minecraft:podzol
setblock -11 80 3 minecraft:moss_block
setblock -11 81 3 minecraft:moss_carpet
setblock -10 80 3 minecraft:coarse_dirt
setblock -10 81 3 minecraft:moss_carpet
setblock -11 80 4 minecraft:podzol
setblock -11 81 4 minecraft:fern
setblock -12 80 3 minecraft:coarse_dirt
setblock 9 80 -4 minecraft:coarse_dirt
setblock 10 80 -4 minecraft:rooted_dirt
setblock 10 81 -4 minecraft:brown_mushroom
setblock 9 80 -3 minecraft:podzol
setblock 9 81 -3 minecraft:moss_carpet
setblock 8 80 -4 minecraft:moss_block
setblock 10 80 3 minecraft:podzol
setblock 10 81 3 minecraft:moss_carpet
setblock 11 80 3 minecraft:podzol
setblock 10 80 4 minecraft:podzol
setblock 10 81 4 minecraft:brown_mushroom
setblock 9 80 3 minecraft:coarse_dirt
setblock 9 81 3 minecraft:moss_carpet
setblock -8 80 8 minecraft:moss_block
setblock -8 81 8 minecraft:fern
setblock -7 80 8 minecraft:moss_block
setblock -7 81 8 minecraft:short_grass
setblock -8 80 9 minecraft:moss_block
setblock -8 81 9 minecraft:moss_carpet
setblock -9 80 8 minecraft:moss_block
setblock -9 81 8 minecraft:fern
setblock 8 80 9 minecraft:moss_block
setblock 9 80 9 minecraft:coarse_dirt
setblock 9 81 9 minecraft:fern
setblock 8 80 10 minecraft:moss_block
setblock 7 80 9 minecraft:coarse_dirt
setblock 7 81 9 minecraft:brown_mushroom
setblock -3 80 -9 minecraft:rooted_dirt
setblock -2 80 -9 minecraft:rooted_dirt
setblock -2 81 -9 minecraft:short_grass
setblock -3 80 -8 minecraft:moss_block
setblock -4 80 -9 minecraft:coarse_dirt
setblock 4 80 -8 minecraft:rooted_dirt
setblock 5 80 -8 minecraft:rooted_dirt
setblock 5 81 -8 minecraft:short_grass
setblock 4 80 -7 minecraft:rooted_dirt
setblock 4 81 -7 minecraft:fern
setblock 3 80 -8 minecraft:podzol
setblock 3 81 -8 minecraft:short_grass
setblock -5 81 -5 minecraft:mossy_stone_brick_wall
setblock -5 82 -5 minecraft:lantern
setblock 5 81 -5 minecraft:mossy_stone_brick_wall
setblock 5 82 -5 minecraft:lantern
setblock -5 81 3 minecraft:mossy_stone_brick_wall
setblock -5 82 3 minecraft:lantern
setblock 5 81 3 minecraft:mossy_stone_brick_wall
setblock 5 82 3 minecraft:lantern
setblock -4 81 8 minecraft:mossy_stone_brick_wall
setblock -4 82 8 minecraft:lantern
setblock 4 81 8 minecraft:mossy_stone_brick_wall
setblock 4 82 8 minecraft:lantern
setblock -4 83 0 minecraft:light[level=14]
setblock 4 83 0 minecraft:light[level=14]
setblock 0 83 4 minecraft:light[level=14]
setblock 0 83 -4 minecraft:light[level=14]
setblock -7 83 -3 minecraft:light[level=14]
setblock 7 83 -3 minecraft:light[level=14]
setblock -6 83 7 minecraft:light[level=14]
setblock 6 83 7 minecraft:light[level=14]
setblock -4 81 -8 minecraft:dark_oak_log[axis=z]
setblock -4 82 -8 minecraft:moss_carpet
setblock 6 81 -6 minecraft:dark_oak_log[axis=z]
setblock 6 82 -6 minecraft:moss_carpet
setblock 7 81 6 minecraft:dark_oak_log[axis=x]
setblock 7 82 6 minecraft:moss_carpet
setblock -8 81 3 minecraft:dark_oak_log[axis=x]
setblock -8 82 3 minecraft:moss_carpet
setblock 2 81 2 minecraft:chiseled_tuff_bricks
setblock 2 82 2 minecraft:polished_blackstone_button[face=floor,facing=north,powered=false]
setworldspawn 0 81 5 180
summon minecraft:item_display 0.5 81 0.5 {Tags:["dl.set","dl.base"],billboard:"fixed",brightness:{block:15,sky:13},view_range:1.0f,teleport_duration:0,item_display:"none",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"drawlab:pedestal"}},transformation:{translation:[0f,0f,0f],scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:item_display 0.5 81 0.5 {Tags:["dl.set","dl.dial"],billboard:"fixed",brightness:{block:15,sky:13},view_range:1.0f,teleport_duration:0,item_display:"none",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"drawlab:dial"}},transformation:{translation:[0f,0f,0f],scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:item_display 0.5 82.055 1.75 {Tags:["dl.set","dl.pointer"],billboard:"fixed",brightness:{block:15,sky:13},view_range:1.0f,teleport_duration:0,item_display:"none",item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"drawlab:pointer"}},transformation:{translation:[0f,0f,0f],scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:text_display 0.5 84.15 0.22 {Tags:["dl.set"],billboard:"vertical",background:0,shadow:1b,brightness:{block:15,sky:15},text:{"text":"渊海 · 精器","color":"#e5d2a7","bold":true},transformation:{translation:[0f,0f,0f],scale:[1.13000f,1.13000f,1.13000f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon minecraft:text_display 2.5 82.37 2.5 {Tags:["dl.set"],billboard:"vertical",background:0,shadow:1b,brightness:{block:15,sky:15},text:{"text":"抽取","color":"#f3dbb2","bold":false},transformation:{translation:[0f,0f,0f],scale:[0.83000f,0.83000f,0.83000f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
scoreboard players set #built dl.state 1
