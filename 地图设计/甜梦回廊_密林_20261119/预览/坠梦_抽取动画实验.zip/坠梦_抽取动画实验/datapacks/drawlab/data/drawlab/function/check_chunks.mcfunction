execute if score #built dl.state matches 1 run return 0
execute in minecraft:overworld unless loaded -16 80 -16 run return run schedule function drawlab:check_chunks 6t replace
execute in minecraft:overworld unless loaded -16 80 0 run return run schedule function drawlab:check_chunks 6t replace
execute in minecraft:overworld unless loaded -16 80 16 run return run schedule function drawlab:check_chunks 6t replace
execute in minecraft:overworld unless loaded 0 80 -16 run return run schedule function drawlab:check_chunks 6t replace
execute in minecraft:overworld unless loaded 0 80 0 run return run schedule function drawlab:check_chunks 6t replace
execute in minecraft:overworld unless loaded 0 80 16 run return run schedule function drawlab:check_chunks 6t replace
execute in minecraft:overworld unless loaded 16 80 -16 run return run schedule function drawlab:check_chunks 6t replace
execute in minecraft:overworld unless loaded 16 80 0 run return run schedule function drawlab:check_chunks 6t replace
execute in minecraft:overworld unless loaded 16 80 16 run return run schedule function drawlab:check_chunks 6t replace
execute in minecraft:overworld run function drawlab:build
