data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.69254f,0f,0.72138f]}}
tp @e[tag=dl.card_0,distance=0..,limit=1] 0.7384 82.5604 1.6761
data merge entity @e[tag=dl.card_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.7384 82.5604 1.7581
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_1,distance=0..,limit=1] -0.6307 82.4604 0.7292
data merge entity @e[tag=dl.card_1,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.94024f,0.94024f,0.94024f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_1,distance=0..,limit=1] -0.6307 82.4604 0.8112
data merge entity @e[tag=dl.icon_1,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.58295f,0.58295f,0.58295f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
particle minecraft:electric_spark -0.6307 82.4604 0.7292 .10 .14 .12 .018 4 normal
tp @e[tag=dl.card_2,distance=0..,limit=1] 0.2616 82.5716 -0.6761
data merge entity @e[tag=dl.card_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_2,distance=0..,limit=1] 0.2616 82.5716 -0.5941
data merge entity @e[tag=dl.icon_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_3,distance=0..,limit=1] 1.6761 82.5614 0.2616
data merge entity @e[tag=dl.card_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_3,distance=0..,limit=1] 1.6761 82.5614 0.3436
data merge entity @e[tag=dl.icon_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
playsound minecraft:block.note_block.bit block @a[distance=..28] 0.5 81 0.5 .29 1.12
particle minecraft:dust{color:[.32,.73,.62],scale:.69} 0.7483 82.05 1.7251 .022 .018 .022 0 2 normal
particle minecraft:dust{color:[.32,.73,.62],scale:.69} 1.0549 82.05 1.6201 .022 .018 .022 0 2 normal
particle minecraft:dust{color:[.32,.73,.62],scale:.69} 1.3242 82.05 1.4398 .022 .018 .022 0 2 normal
