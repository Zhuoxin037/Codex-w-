data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.33829f,0f,0.94104f]}}
kill @e[tag=dl.left,distance=0..,limit=1]
kill @e[tag=dl.right,distance=0..,limit=1]
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.5 83.17 0.822
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.44300f,1.44300f,1.44300f],left_rotation:[0f,0.10481f,0f,0.99449f]}}
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.39 83.03 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.3223 83.3706 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.1293 83.6593 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.8406 83.8523 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.5 83.92 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.1594 83.8523 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.1293 83.6593 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.3223 83.3706 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.39 83.03 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.3223 82.6894 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.1293 82.4007 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.1594 82.2077 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.5 82.14 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.8406 82.2077 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.1293 82.4007 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.3223 82.6894 0.82 .018 .018 .014 0 1 normal
