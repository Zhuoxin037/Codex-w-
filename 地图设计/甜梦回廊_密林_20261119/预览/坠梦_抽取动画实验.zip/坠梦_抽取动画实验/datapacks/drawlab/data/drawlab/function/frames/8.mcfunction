data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.16918f,0f,0.98558f]}}
tp @e[tag=dl.card_0,distance=0..,limit=1] 0.7415 82.415 -0.461
data merge entity @e[tag=dl.card_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.75102f,0.75102f,0.75102f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.7415 82.415 -0.379
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.46563f,0.46563f,0.46563f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_1,distance=0..,limit=1] 1.461 82.4027 0.7415
data merge entity @e[tag=dl.card_1,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.75102f,0.75102f,0.75102f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_1,distance=0..,limit=1] 1.461 82.4027 0.8235
data merge entity @e[tag=dl.icon_1,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.46563f,0.46563f,0.46563f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_2,distance=0..,limit=1] 0.2585 82.3977 1.461
data merge entity @e[tag=dl.card_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.75102f,0.75102f,0.75102f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_2,distance=0..,limit=1] 0.2585 82.3977 1.543
data merge entity @e[tag=dl.icon_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.46563f,0.46563f,0.46563f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_3,distance=0..,limit=1] -0.461 82.4046 0.2585
data merge entity @e[tag=dl.card_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.75102f,0.75102f,0.75102f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_3,distance=0..,limit=1] -0.461 82.4046 0.3405
data merge entity @e[tag=dl.icon_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.46563f,0.46563f,0.46563f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
playsound minecraft:block.note_block.bit block @a[distance=..28] 0.5 81 0.5 .29 1.55
particle minecraft:dust{color:[.32,.73,.62],scale:.69} 0.8047 82.05 -0.7123 .022 .018 .022 0 2 normal
particle minecraft:dust{color:[.32,.73,.62],scale:.69} 0.4828 82.05 -0.7499 .022 .018 .022 0 2 normal
particle minecraft:dust{color:[.32,.73,.62],scale:.69} 0.1621 82.05 -0.7035 .022 .018 .022 0 2 normal
