data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.29313f,0f,0.95607f]}}
tp @e[tag=dl.left,distance=0..,limit=1] 0.7739 82.7653 0.7237
data merge entity @e[tag=dl.left,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00423f,1.00423f,1.00423f],left_rotation:[0f,0.06264f,0f,0.99804f]}}
tp @e[tag=dl.right,distance=0..,limit=1] 0.2261 82.7653 0.7237
data merge entity @e[tag=dl.right,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00423f,1.00423f,1.00423f],left_rotation:[0f,-0.06264f,0f,0.99804f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.5 83.095 0.822
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.10177f,1.10177f,1.10177f],left_rotation:[0f,0.04873f,0f,0.99881f]}}
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.1061 83.03 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.06 83.2619 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.9286 83.4586 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.7319 83.59 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.5 83.6361 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.2681 83.59 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.0714 83.4586 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.06 83.2619 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.1061 83.03 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.06 82.7981 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.0714 82.6014 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.2681 82.47 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.5 82.4239 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.7319 82.47 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.9286 82.6014 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.06 82.7981 0.82 .018 .018 .014 0 1 normal
