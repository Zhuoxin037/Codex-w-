scoreboard players set #time dl.state -1
scoreboard players set #pressed dl.state 0
kill @e[tag=dl.play,distance=0..]
data merge entity @e[tag=dl.dial,distance=0..,limit=1] {transformation:{left_rotation:[0f,0f,0f,1f]}}
