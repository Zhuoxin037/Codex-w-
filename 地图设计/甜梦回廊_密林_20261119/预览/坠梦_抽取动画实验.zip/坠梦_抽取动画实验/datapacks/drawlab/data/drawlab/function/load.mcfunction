scoreboard objectives add dl.state dummy
gamerule doMobSpawning false
gamerule doWeatherCycle false
gamerule doDaylightCycle false
gamerule spawnRadius 0
difficulty peaceful
time set 11040
execute in minecraft:overworld run function drawlab:reset
execute in minecraft:overworld run forceload add -16 -16 16 16
execute unless score #built dl.state matches 1 run schedule function drawlab:check_chunks 6t replace
