execute as @a[tag=!dl.welcome,distance=0..] at @s run function drawlab:join
execute as @a[distance=0..] at @s if entity @s[y=40,dy=-103] run tp @s 0.5 81 5.4 180 3
execute if score #time dl.state matches 0.. run function drawlab:advance
execute if block 2 82 2 minecraft:polished_blackstone_button[powered=true] run function drawlab:pressed
execute unless block 2 82 2 minecraft:polished_blackstone_button[powered=true] run scoreboard players set #pressed dl.state 0
