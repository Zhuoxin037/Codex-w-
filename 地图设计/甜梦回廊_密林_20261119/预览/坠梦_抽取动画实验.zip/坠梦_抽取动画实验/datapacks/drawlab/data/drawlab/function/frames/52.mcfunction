data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.30449f,0f,0.95252f]}}
tp @e[tag=dl.left,distance=0..,limit=1] 0.973 82.573 0.7119
data merge entity @e[tag=dl.left,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.78929f,0.78929f,0.78929f],left_rotation:[0f,0.10802f,0f,0.99415f]}}
tp @e[tag=dl.right,distance=0..,limit=1] 0.027 82.573 0.7119
data merge entity @e[tag=dl.right,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.78929f,0.78929f,0.78929f],left_rotation:[0f,-0.10802f,0f,0.99415f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.5 83.1422 0.822
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.31671f,1.31671f,1.31671f],left_rotation:[0f,0.08408f,0f,0.99646f]}}
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.2849 83.03 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.2252 83.3304 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.055 83.585 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.8004 83.7552 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.5 83.8149 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.1996 83.7552 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.055 83.585 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.2252 83.3304 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.2849 83.03 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.2252 82.7296 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} -0.055 82.475 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.1996 82.3048 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.5 82.2451 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 0.8004 82.3048 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.055 82.475 0.82 .018 .018 .014 0 1 normal
particle minecraft:dust{color:[.46,.86,.74],scale:.63} 1.2252 82.7296 0.82 .018 .018 .014 0 1 normal
particle minecraft:end_rod 0.5 83.03 0.8 .36 .34 .12 .035 22 normal
execute if score #draw dl.state matches 0 run function drawlab:result/0
execute if score #draw dl.state matches 1 run function drawlab:result/1
execute if score #draw dl.state matches 2 run function drawlab:result/2
execute if score #draw dl.state matches 3 run function drawlab:result/3
