data merge entity @e[tag=dl.dial,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{left_rotation:[0f,-0.45066f,0f,0.89270f]}}
tp @e[tag=dl.card_0,distance=0..,limit=1] 0.7487 82.5728 -0.6739
data merge entity @e[tag=dl.card_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_0,distance=0..,limit=1] 0.7487 82.5728 -0.5919
data merge entity @e[tag=dl.icon_0,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_1,distance=0..,limit=1] 1.6739 82.5686 0.7487
data merge entity @e[tag=dl.card_1,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_1,distance=0..,limit=1] 1.6739 82.5686 0.8307
data merge entity @e[tag=dl.icon_1,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_2,distance=0..,limit=1] 0.2513 82.5565 1.6739
data merge entity @e[tag=dl.card_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_2,distance=0..,limit=1] 0.2513 82.5565 1.7559
data merge entity @e[tag=dl.icon_2,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.card_3,distance=0..,limit=1] -0.6739 82.5476 0.2513
data merge entity @e[tag=dl.card_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[1.00000f,1.00000f,1.00000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
tp @e[tag=dl.icon_3,distance=0..,limit=1] -0.6739 82.5476 0.3333
data merge entity @e[tag=dl.icon_3,distance=0..,limit=1] {start_interpolation:0,interpolation_duration:2,transformation:{scale:[0.62000f,0.62000f,0.62000f],left_rotation:[0f,0.00000f,0f,1.00000f]}}
playsound minecraft:block.note_block.bit block @a[distance=..28] 0.5 81 0.5 .29 1.4
